# Serene — Massage Booking Simulator

A small, responsive massage appointment booking simulator built with **HTML, CSS, and vanilla JavaScript**. Made as a beginner-friendly portfolio project for GitHub.

## Features

- Responsive landing page and service cards
- Three selectable demo massage services with prices and durations
- Booking form with required-field and date validation
- Date and time-slot selection
- Dynamic price total
- Demo booking confirmation and generated booking ID
- Booking history saved in browser `localStorage`
- Remove one booking or clear all booking history
- No framework, server, API key, or installation required

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a browser.

For a local development server, you can use VS Code's **Live Server** extension.

## Publish on GitHub

1. Sign in to GitHub and create a new repository, for example `massage-booking-simulator`.
2. Keep it Public if you want to showcase it in your portfolio.
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` (or push them using Git).
4. To publish a live demo, open the repository's **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to deploy and open the URL shown in the Pages section.

## Important limitations

This is a **front-end simulator**, not a production booking platform:
- Bookings are stored only in the current browser on the current device.
- It does not send emails, process payments, authenticate users, or reserve a real therapist.
- Clearing browser site data can remove saved bookings.
- Do not enter sensitive personal information.

## Project structure

```text
massage-booking-simulator/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Ideas to improve it

- Add a Python Flask backend and SQLite database
- Add an admin dashboard for managing appointments
- Add login and email confirmations
- Add real availability checks and payment integration (with secure server-side handling)

## License

Use and modify this project for learning and portfolio purposes.
