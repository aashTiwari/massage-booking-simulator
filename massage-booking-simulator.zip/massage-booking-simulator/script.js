const services = [
  {id:"swedish",name:"Swedish Reset",duration:60,price:799,desc:"Gentle, flowing techniques to help you relax and reset.",symbol:"☼",tag:"MOST LOVED"},
  {id:"deep",name:"Deep Tissue",duration:60,price:999,desc:"Focused pressure for tired muscles and everyday tension.",symbol:"◉",tag:"TARGETED CARE"},
  {id:"head",name:"Head & Shoulder",duration:30,price:499,desc:"A shorter session focused on the places that carry stress.",symbol:"❋",tag:"QUICK RESET"}
];
const $ = (selector) => document.querySelector(selector);
const serviceGrid = $("#serviceGrid");
const serviceSelect = $("#serviceSelect");
const totalPrice = $("#totalPrice");
const bookingForm = $("#bookingForm");
const historyEl = $("#bookingHistory");
const dialog = $("#successDialog");
let selectedService = services[0].id;
let toastTimer;

function rupees(value){ return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(value); }
function getService(id){ return services.find(service => service.id === id) || services[0]; }
function renderServices(){
  serviceGrid.innerHTML = services.map(service => `
    <article class="service-card ${service.id===selectedService?"selected":""}" data-service="${service.id}" tabindex="0" role="button" aria-label="Select ${service.name}">
      <div class="service-art"><span class="service-symbol">${service.symbol}</span></div>
      <div class="service-info">
        <div class="service-meta"><span>${service.tag}</span><span>${service.duration} MIN</span></div>
        <h3>${service.name}</h3><p>${service.desc}</p>
        <div class="service-bottom"><span class="price">${rupees(service.price)} <small>/ session</small></span><button class="choose-btn" type="button">Choose ↗</button></div>
      </div>
    </article>`).join("");
  serviceSelect.innerHTML = services.map(s => `<option value="${s.id}">${s.name} — ${rupees(s.price)} (${s.duration} min)</option>`).join("");
  serviceSelect.value = selectedService;
  updateTotal();
}
function updateTotal(){ totalPrice.textContent = rupees(getService(serviceSelect.value || selectedService).price); }
function selectService(id, scrollToForm=false){
  selectedService = id;
  serviceSelect.value = id;
  renderServices();
  updateTotal();
  if(scrollToForm) $("#booking").scrollIntoView({behavior:"smooth"});
}
function showToast(message){
  const toast=$("#toast"); toast.textContent=message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>toast.classList.remove("show"),2600);
}
function getBookings(){
  try { return JSON.parse(localStorage.getItem("sereneBookings") || "[]"); }
  catch { return []; }
}
function saveBookings(bookings){ localStorage.setItem("sereneBookings",JSON.stringify(bookings)); }
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function readableDate(dateString){
  const date = new Date(dateString+"T12:00:00");
  return date.toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});
}
function renderHistory(){
  const bookings=getBookings().sort((a,b)=>b.createdAt-a.createdAt);
  if(!bookings.length){
    historyEl.innerHTML='<div class="empty-state"><span>✦</span><h3>Your next reset goes here.</h3><p>Demo bookings you create will appear in this section.</p></div>'; return;
  }
  historyEl.innerHTML=bookings.map(b=>`
    <article class="booking-item">
      <div><h3>${escapeHtml(b.serviceName)}</h3><p>${escapeHtml(b.name)} · ${escapeHtml(readableDate(b.date))} at ${escapeHtml(b.time)}<br>Booking ID: ${escapeHtml(b.id)}</p></div>
      <div class="booking-right"><strong>${rupees(b.price)}</strong><span>DEMO CONFIRMED</span><br><button class="booking-delete" data-delete="${escapeHtml(b.id)}">Remove booking</button></div>
    </article>`).join("");
}
function setMinimumDate(){
  const now=new Date();
  const localDate=new Date(now.getTime()-now.getTimezoneOffset()*60000).toISOString().slice(0,10);
  $("#sessionDate").min=localDate;
  $("#sessionDate").value=localDate;
}
serviceGrid.addEventListener("click",event=>{
  const card=event.target.closest("[data-service]");
  if(card) selectService(card.dataset.service,true);
});
serviceGrid.addEventListener("keydown",event=>{
  if((event.key==="Enter"||event.key===" ") && event.target.matches("[data-service]")){
    event.preventDefault(); selectService(event.target.dataset.service,true);
  }
});
serviceSelect.addEventListener("change",()=>{selectedService=serviceSelect.value;renderServices();});
$("#navBook").addEventListener("click",()=>$("#booking").scrollIntoView({behavior:"smooth"}));
bookingForm.addEventListener("submit",event=>{
  event.preventDefault();
  if(!bookingForm.reportValidity()) return;
  const date=$("#sessionDate").value;
  const today=new Date(); today.setHours(0,0,0,0);
  if(new Date(date+"T00:00:00")<today){showToast("Please choose today or a future date.");return;}
  const service=getService(serviceSelect.value);
  const booking={
    id:"SRN-"+Date.now().toString().slice(-7),
    serviceId:service.id,serviceName:service.name,price:service.price,duration:service.duration,
    date,time:$("#sessionTime").value,name:$("#customerName").value.trim(),
    email:$("#customerEmail").value.trim(),notes:$("#notes").value.trim(),createdAt:Date.now()
  };
  const bookings=getBookings(); bookings.push(booking); saveBookings(bookings); renderHistory();
  $("#successText").textContent=`${booking.serviceName} for ${readableDate(booking.date)} at ${booking.time} is saved in this browser. Booking ID: ${booking.id}. No real appointment or payment was made.`;
  dialog.showModal(); bookingForm.reset(); setMinimumDate(); selectedService=service.id; renderServices();
});
historyEl.addEventListener("click",event=>{
  const button=event.target.closest("[data-delete]");
  if(!button)return;
  saveBookings(getBookings().filter(b=>b.id!==button.dataset.delete)); renderHistory(); showToast("Demo booking removed.");
});
$("#clearBookings").addEventListener("click",()=>{
  const bookings=getBookings();
  if(!bookings.length){showToast("There is no booking history to clear.");return;}
  if(confirm("Clear all demo bookings saved in this browser?")){saveBookings([]);renderHistory();showToast("Booking history cleared.");}
});
function closeDialog(){dialog.close();}
$("#closeDialog").addEventListener("click",closeDialog);
$("#dialogDone").addEventListener("click",closeDialog);
dialog.addEventListener("click",event=>{if(event.target===dialog)closeDialog();});
renderServices(); setMinimumDate(); renderHistory();
